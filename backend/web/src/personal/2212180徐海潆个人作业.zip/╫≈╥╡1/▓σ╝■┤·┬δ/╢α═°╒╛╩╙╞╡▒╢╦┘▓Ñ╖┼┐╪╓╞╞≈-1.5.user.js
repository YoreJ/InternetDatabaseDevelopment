// ==UserScript==
// @name         多网站视频倍速播放控制器
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  为多个视频网站（如Bilibili、YouTube、Vimeo、腾讯视频、爱奇艺、芒果TV）上的视频播放器添加倍速播放控制功能，最高可达5x
// @author       你的名字
// @match        *://www.bilibili.com/video/*
// @match        *://www.youtube.com/watch*
// @match        *://vimeo.com/*
// @match        *://v.qq.com/x/*
// @match        *://www.iqiyi.com/v_*
// @match        *://www.mgtv.com/b/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    console.log('多网站视频倍速播放控制器脚本已启动');

    // 倍速选项（已扩展至5x）
    const speedOptions = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4, 5];

    // 创建控制面板容器
    const controlPanel = document.createElement('div');
    controlPanel.id = 'videoSpeedControlPanel';
    controlPanel.style.position = 'fixed';
    controlPanel.style.bottom = '20px';
    controlPanel.style.right = '20px';
    controlPanel.style.padding = '10px';
    controlPanel.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    controlPanel.style.borderRadius = '5px';
    controlPanel.style.zIndex = '10000';
    controlPanel.style.display = 'flex';
    controlPanel.style.flexDirection = 'column';
    controlPanel.style.alignItems = 'center';
    controlPanel.style.color = '#fff';
    controlPanel.style.fontFamily = 'Arial, sans-serif';
    controlPanel.style.boxShadow = '0 0 10px rgba(0,0,0,0.5)';
    controlPanel.style.transition = 'opacity 0.3s';
    controlPanel.style.opacity = '0.8';

    // 添加标题
    const title = document.createElement('span');
    title.innerText = '倍速控制';
    title.style.marginBottom = '5px';
    controlPanel.appendChild(title);

    // 创建并添加倍速按钮
    speedOptions.forEach(speed => {
        const button = document.createElement('button');
        button.innerText = `${speed}x`;
        button.style.margin = '2px';
        button.style.padding = '5px 10px';
        button.style.border = 'none';
        button.style.borderRadius = '3px';
        button.style.backgroundColor = '#007BFF';
        button.style.color = '#fff';
        button.style.cursor = 'pointer';
        button.style.fontSize = '14px';
        button.dataset.speed = speed;
        controlPanel.appendChild(button);
    });

    // 将控制面板添加到页面
    document.body.appendChild(controlPanel);
    console.log('倍速控制面板已添加到页面');

    /**
     * 获取当前网站标识
     * @returns {string} 网站标识（如 'bilibili', 'youtube', 'vimeo', 'tencent', 'iqiyi', 'mgtv'）
     */
    function getSite() {
        const hostname = window.location.hostname;
        if (hostname.includes('bilibili.com')) {
            return 'bilibili';
        } else if (hostname.includes('youtube.com')) {
            return 'youtube';
        } else if (hostname.includes('vimeo.com')) {
            return 'vimeo';
        } else if (hostname.includes('v.qq.com')) {
            return 'tencent';
        } else if (hostname.includes('iqiyi.com')) {
            return 'iqiyi';
        } else if (hostname.includes('mgtv.com')) {
            return 'mgtv';
        }
        return 'other';
    }

    /**
     * 获取当前页面上的所有视频元素
     * 支持多个视频网站（Bilibili、YouTube、Vimeo、腾讯视频、爱奇艺、芒果TV等）
     * @returns {NodeListOf<HTMLVideoElement>} 视频元素列表
     */
    function getVideos() {
        const site = getSite();
        switch (site) {
            case 'bilibili':
                return document.querySelectorAll('video');
            case 'youtube':
                // YouTube 使用多个 video 元素，主要的在 .video-stream 类中
                return document.querySelectorAll('video.video-stream');
            case 'vimeo':
                return document.querySelectorAll('video');
            case 'tencent':
                // 腾讯视频使用自定义播放器，视频元素可能带有特定类名
                return document.querySelectorAll('video, .player_video');
            case 'iqiyi':
                // 爱奇艺使用自定义播放器，通常为 video 标签
                return document.querySelectorAll('video');
            case 'mgtv':
                // 芒果TV使用自定义播放器，通常为 video 标签
                return document.querySelectorAll('video');
            default:
                // 默认使用所有 video 元素
                return document.querySelectorAll('video');
        }
    }

    /**
     * 判断节点是否为视频元素
     * 支持多个视频网站
     * @param {Node} node
     * @returns {boolean}
     */
    function isVideoElement(node) {
        if (node.nodeType !== Node.ELEMENT_NODE) return false;
        const site = getSite();
        switch (site) {
            case 'bilibili':
                return node.tagName === 'VIDEO';
            case 'youtube':
                return node.tagName === 'VIDEO' && node.classList.contains('video-stream');
            case 'vimeo':
                return node.tagName === 'VIDEO';
            case 'tencent':
                // 腾讯视频使用自定义播放器，视频元素可能带有特定类名
                return node.tagName === 'VIDEO' || node.classList.contains('player_video');
            case 'iqiyi':
                // 爱奇艺使用自定义播放器，通常为 video 标签
                return node.tagName === 'VIDEO';
            case 'mgtv':
                // 芒果TV使用自定义播放器，通常为 video 标签
                return node.tagName === 'VIDEO';
            default:
                return node.tagName === 'VIDEO';
        }
    }

    // 更新视频播放速度函数
    function updateVideoSpeed(speed) {
        const videos = getVideos();
        if (videos.length === 0) {
            console.log('当前页面没有检测到视频元素');
            return;
        }
        videos.forEach(video => {
            video.playbackRate = speed;
            console.log(`设置视频播放速度为 ${speed}x`);
        });
        // 保存到localStorage
        localStorage.setItem('preferredPlaybackRate', speed);
    }

    // 为每个按钮添加点击事件监听器
    controlPanel.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', () => {
            const speed = parseFloat(button.dataset.speed);
            updateVideoSpeed(speed);
            // 高亮选中的按钮
            controlPanel.querySelectorAll('button').forEach(btn => {
                btn.style.backgroundColor = '#007BFF';
            });
            button.style.backgroundColor = '#28a745';
            console.log(`用户选择了 ${speed}x 播放速度`);
        });
    });

    // 监测动态添加的视频元素
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.addedNodes.length) {
                mutation.addedNodes.forEach(node => {
                    if (isVideoElement(node)) {
                        console.log('新视频元素已添加到页面');
                        // 自动应用当前选定的播放速度
                        const currentSpeed = getCurrentSpeed();
                        node.playbackRate = currentSpeed;
                        console.log(`新视频播放速度已设置为 ${currentSpeed}x`);
                    }
                });
            }
        });
    });

    observer.observe(document.body, { childList: true, subtree: true });
    console.log('MutationObserver已启动');

    /**
     * 获取当前选定的播放速度
     * 优先从高亮按钮获取，其次从localStorage获取
     * @returns {number} 当前播放速度
     */
    function getCurrentSpeed() {
        const highlightedButton = controlPanel.querySelector('button[style*="background-color: rgb(40, 167, 69)"], button[style*="background-color: #28a745"]');
        if (highlightedButton) {
            return parseFloat(highlightedButton.dataset.speed);
        }
        // 尝试从localStorage获取
        const savedSpeed = parseFloat(localStorage.getItem('preferredPlaybackRate'));
        if (!isNaN(savedSpeed)) {
            return savedSpeed;
        }
        return 1; // 默认速度
    }

    // 页面加载时应用保存的速度
    window.addEventListener('load', () => {
        const savedSpeed = getCurrentSpeed();
        updateVideoSpeed(savedSpeed);
        // 高亮对应按钮
        controlPanel.querySelectorAll('button').forEach(btn => {
            if (parseFloat(btn.dataset.speed) === savedSpeed) {
                btn.style.backgroundColor = '#28a745';
            } else {
                btn.style.backgroundColor = '#007BFF';
            }
        });
        console.log(`页面加载时已应用保存的播放速度: ${savedSpeed}x`);
    });

    // 自动隐藏控制面板，当鼠标悬停时显示，离开时隐藏
    controlPanel.addEventListener('mouseenter', () => {
        controlPanel.style.opacity = '1';
    });

    controlPanel.addEventListener('mouseleave', () => {
        controlPanel.style.opacity = '0.8';
    });

    // 添加快捷键支持
    window.addEventListener('keydown', (e) => {
        if (e.shiftKey && e.key === 'ArrowUp') {
            increaseSpeed();
        } else if (e.shiftKey && e.key === 'ArrowDown') {
            decreaseSpeed();
        }
    });

    /**
     * 增加播放速度
     */
    function increaseSpeed() {
        let currentSpeed = getCurrentSpeed();
        const newSpeed = Math.min(currentSpeed + 0.25, 5);
        updateVideoSpeed(newSpeed);
        highlightButton(newSpeed);
        console.log(`通过快捷键增加播放速度到 ${newSpeed}x`);
    }

    /**
     * 减少播放速度
     */
    function decreaseSpeed() {
        let currentSpeed = getCurrentSpeed();
        const newSpeed = Math.max(currentSpeed - 0.25, 0.25);
        updateVideoSpeed(newSpeed);
        highlightButton(newSpeed);
        console.log(`通过快捷键减少播放速度到 ${newSpeed}x`);
    }

    /**
     * 高亮显示对应的倍速按钮
     * @param {number} speed
     */
    function highlightButton(speed) {
        controlPanel.querySelectorAll('button').forEach(btn => {
            if (parseFloat(btn.dataset.speed) === speed) {
                btn.style.backgroundColor = '#28a745';
            } else {
                btn.style.backgroundColor = '#007BFF';
            }
        });
    }

})();
