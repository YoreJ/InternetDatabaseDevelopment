# [BootstrapVue Argon Dashboard](https://demos.creative-tim.com/bootstrap-vue-argon-dashboard/?ref=bvad-github-readme) [![Tweet](https://img.shields.io/twitter/url/http/shields.io.svg?style=social&logo=twitter)](https://twitter.com/home?status=BootstrapVue%20Argon%20Dashboard%20is%20a%20Free%20Bootstrap%20and%Vue.js%20Dashboard%20made%20using%vue-cli%20%E2%9D%A4%EF%B8%8F%0Ahttps%3A//demos.creative-tim.com/bootstrap-vue-argon-dashboard%20%vue.js%20%23vue-cli%20%23argon%20%23argondesign%20%23angulardashboard%20%23argonvue%20%23vuedesign%20%23bootstrap%20%23design%20%23uikit%20%23freebie%20%20via%20%40CreativeTim)

![version](https://img.shields.io/badge/version-1.0.0-blue.svg)  ![license](https://img.shields.io/badge/license-MIT-blue.svg) [![GitHub issues open](https://img.shields.io/github/issues/creativetimofficial/bootstrap-vue-argon-dashboard.svg?maxAge=2592000)](https://github.com/creativetimofficial/bootstrap-vue-argon-dashboard/issues?q=is%3Aopen+is%3Aissue) [![GitHub issues closed](https://img.shields.io/github/issues-closed-raw/creativetimofficial/bootstrap-vue-argon-dashboard.svg?maxAge=2592000)](https://github.com/creativetimofficial/bootstrap-vue-argon-dashboard/issues?q=is%3Aissue+is%3Aclosed) [![Join the chat at https://gitter.im/NIT-dgp/General](https://badges.gitter.im/NIT-dgp/General.svg)](https://gitter.im/creative-tim-general/Lobby) [![Chat](https://img.shields.io/badge/chat-on%20discord-7289da.svg)](https://discord.gg/E4aHAQy)

![Product Gif](https://raw.githubusercontent.com/creativetimofficial/public-assets/master/vue-argon-dashboard/vue-argon-dashboard.gif)

**完整编码的组件**

BootstrapVue Argon Dashboard 是由 100 多个独立组件构建而成，给予您自由选择和组合的空间。所有组件都可以在颜色上进行变化，您可以轻松使用 SASS 文件进行修改。

由于所有元素都已实现，您将在从原型设计到完全功能代码的过程中节省大量时间。这个仪表板配备了预构建的示例，使开发过程无缝，切换我们的页面到实际网站非常容易完成。

每个元素都有多种状态，如颜色、样式、悬停、聚焦，您可以轻松访问和使用。

**复杂的文档**

每个元素在非常详细的文档中都有很好的展示。您可以在[此处](https://www.creative-tim.com/learning-lab/bootstrap-vue/overview/argon-dashboard?ref=bvad-github-readme)阅读关于这个仪表板背后的理念。您可以在[这里](https://www.creative-tim.com/learning-lab/bootstrap-vue/avatar/argon-dashboard?ref=bvad-github-readme)查看组件，及在[这里](https://www.creative-tim.com/learning-lab/bootstrap-vue/colors/argon-dashboard?ref=bvad-github-readme)查看基础。

**示例页面**

如果您想获得灵感或只是直接向客户展示一些内容，您可以使用我们预构建的示例页面快速启动您的开发。您将能够快速为您的网络项目设置基本结构。

## 目录

* [版本](#versions)
* [演示](#demo)
* [快速开始](#quick-start)
* [部署](#deploy)
* [文档](#documentation)
* [文件结构](#file-structure)
* [浏览器支持](#browser-support)
* [资源](#resources)
* [报告问题](#reporting-issues)
* [许可](#licensing)
* [有用的链接](#useful-links)

## 版本

[<img src="https://github.com/creativetimofficial/public-assets/blob/master/logos/bootstrap-vue-logo.jpg?raw=true" width="60" height="60" />](https://www.creative-tim.com/product/bootstrap-vue-argon-dashboard)[<img src="https://github.com/creativetimofficial/public-assets/blob/master/logos/vue-logo.jpg?raw=true" width="60" height="60" />](https://www.creative-tim.com/product/vue-argon-dashboard)[<img src="https://github.com/creativetimofficial/public-assets/blob/master/logos/html-logo.jpg?raw=true" width="60" height="60" />](https://www.creative-tim.com/product/argon-dashboard)[<img src="https://github.com/creativetimofficial/public-assets/blob/master/logos/react-logo.jpg?raw=true" width="60" height="60" />](https://www.creative-tim.com/product/argon-dashboard-react)[<img src="https://github.com/creativetimofficial/public-assets/blob/master/logos/angular-logo.jpg?raw=true" width="60" height="60" />](https://www.creative-tim.com/product/vue-argon-dashboard)[<img src="https://github.com/creativetimofficial/public-assets/blob/master/logos/nodejs-logo.jpg?raw=true" width="60" height="60" />](https://www.creative-tim.com/product/argon-dashboard-nodejs)[<img src="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/logos/laravel_logo.png" width="60" height="60" style="background:white"/>](https://www.creative-tim.com/product/argon-dashboard-laravel)[<img src="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/logos/sketch-logo.jpg" width="60" height="60" />](https://github.com/creativetimofficial/argon-dashboard/tree/sketch)

|Vue | HTML | React | Angular  |
| --- | --- | ---  | --- |
[![Vue Argon Dashboard](https://github.com/creativetimofficial/public-assets/blob/master/vue-argon-dashboard/vue-argon-dashboard.jpg?raw=true)](https://www.creative-tim.com/product/vue-argon-dashboard?ref=bvad-github-readme) | [![Argon Dashboard HTML](https://github.com/creativetimofficial/public-assets/blob/master/argon-dashboard/argon-dashboard.jpg?raw=true)](https://www.creative-tim.com/product/vue-argon-dashboard?ref=bvad-github-readme) | [![Argon Dashboard React](https://github.com/creativetimofficial/public-assets/blob/master/argon-dashboard-react/argon-dashboard-react.jpg?raw=true)](https://www.creative-tim.com/product/argon-dashboard-react?ref=bvad-github-readme) | [![Argon Dashboard Angular](https://github.com/creativetimofficial/public-assets/blob/master/argon-dashboard-angular/argon-dashboard-angular.jpg?raw=true)](https://www.creative-tim.com/product/argon-dashboard-angular?ref=bvad-github-readme)

| BootstrapVue | NodeJS | Laravel |
|  ---  | ---  | --- |
| [![BootstrapVue Argon Dashboard](https://github.com/creativetimofficial/public-assets/blob/master/bootstrap-vue-argon-dashboard/opt_ad_bootstrapvue_thumbnail.jpg?raw=true)](https://www.creative-tim.com/product/bootstrap-vue-argon-dashboard?ref=bvad-github-readme) | [![Argon Dashboard NodeJS](https://github.com/creativetimofficial/public-assets/blob/master/argon-dashboard-nodejs/argon-dashboard-nodejs.jpg?raw=true)](https://www.creative-tim.com/product/argon-dashboard-nodejs?ref=bvad-github-readme) | [![Argon Dashboard Laravel](https://github.com/creativetimofficial/public-assets/blob/master/argon-dashboard-laravel/argon-dashboard-laravel.jpg?raw=true)](https://www.creative-tim.com/product/argon-dashboard-laravel?ref=bvad-github-readme) |

## 演示

| 仪表板页面 | 图标页面 | 用户个人资料页面  | 表格页面 | 登录页面 | 注册页面  |
| --- | --- | ---  | --- | --- | ---  |
| [![Dashboard Page](https://raw.githubusercontent.com/creativetimofficial/public-assets/master/vue-argon-dashboard/dashboard.png)](https://demos.creative-tim.com/bootstrap-vue-argon-dashboard/#/dashboard?ref=bvad-github-readme)  | [![Icons Page](https://github.com/creativetimofficial/public-assets/blob/master/vue-argon-dashboard/icons.png?raw=true)](https://demos.creative-tim.com/bootstrap-vue-argon-dashboard/#/icons?ref=bvad-github-readme)  | [![User Profile Page](https://github.com/creativetimofficial/public-assets/blob/master/vue-argon-dashboard/user.png?raw=true)](https://demos.creative-tim.com/bootsrap-vue-argon-dashboard/#/profile?ref=bvad-github-readme)  | [![Tables Page](https://raw.githubusercontent.com/creativetimofficial/public-assets/master/vue-argon-dashboard/tables.png)](https://demos.creative-tim.com/bootstrap-vue-argon-dashboard/#/tables?ref=bvad-github-readme)  | [![Login Page](https://github.com/creativetimofficial/public-assets/blob/master/vue-argon-dashboard/login.png?raw=true)](https://demos.creative-tim.com/bootstrap-vue-argon-dashboard/#/login?ref=bvad-github-readme)  | [![Register Page](https://github.com/creativetimofficial/public-assets/blob/master/vue-argon-dashboard/register.png?raw=true)](https://demos.creative-tim.com/bootsrap-vue-argon-dashboard/#/register?ref=bvad-github-readme)

[查看更多](https://demos.creative-tim.com/bootstrap-vue-argon-dashboard/#/dashboard)

## 快速开始

- [从 Github 下载](https://github.com/creativetimofficial/bootsrap-vue-argon-dashboard/archive/master.zip)。
- [从 Creative Tim 下载](https://www.creative-tim.com/product/bootstrap-vue-argon-dashboard?ref=bvad-github-readme)。
- 克隆仓库: `git clone https://github.com/creativetimofficial/bootstrap-vue-argon-dashboard.git`。

## 部署

:rocket: 您可以一键将模板的自己的版本部署到 Genezio：

[![Deploy to Genezio](https://raw.githubusercontent.com/Genez-io/graphics/main/svg/deploy-button.svg)](https://app.genez.io/start/deploy?repository=https://github.com/creativetimofficial/bootstrap-vue-argon-dashboard&utm_source=github&utm_medium=referral&utm_campaign=github-creativetim&utm_term=deploy-project&utm_content=button-head)

## 文档
BootstrapVue Argon Dashboard 的文档托管在我们的[网站](https://www.creative-tim.com/learning-lab/bootstrap-vue/colors/argon-dashboard?ref=bvad-github-readme)上。

## 文件结构
在下载包中，您会找到以下目录和文件：

```
|-- BootstrapVue Argon Dashboard
    |-- .gitignore
    |-- CHANGELOG.md
    |-- ISSUES_TEMPLATE.md
    |-- LICENSE.md
    |-- README.md
    |-- babel.config.js
    |-- package.json
    |-- public
    |   |-- img
    |   |-- favicon.ico
    |   |-- index.html
    |-- src
        |-- assets
        |   |-- logo.png
        |   |-- scss
        |   |   |-- core
        |   |   |-- custom
        |   |   |-- argon.scss
        |   |-- vendor
        |       |-- nucleo
        |-- components
        |   |-- Badge.vue
        |   |-- BaseAlert.vue
        |   |-- BaseButton.vue
        |   |-- BaseDropdown.vue
        |   |-- BaseHeader.vue
        |   |-- BasePagination.vue
        |   |-- BaseProgress.vue
        |   |-- BaseSlider.vue
        |   |-- BaseTable.vue
        |   |-- ButtonCheckbox.vue
        |   |-- ButtonRadioGroup.vue
        |   |-- CloseButton.vue
        |   |-- index.js
        |   |-- LoadingPanel.vue
        |   |-- Modal.vue
        |   |-- NavbarToggleButton.vue
        |   |-- Breadcrumb
        |   |   |-- Breadcrumb.vue
        |   |   |-- BreadcrumbItem.vue
        |   |   |-- RouteBreadcrumb.vue
        |   |-- Cards
        |   |   |-- Card.vue
        |   |   |-- StatsCard.vue
        |   |-- Charts
        |   |   |-- BarChart.js
        |   |   |-- config.js
        |   |   |-- globalOptionsMixin.js
        |   |   |-- LineChart.js
        |   |   |-- optionHelpers.js
        |   |   |-- roundedCornersExtension.js
        |   |-- Collapse
        |   |   |-- Collapse.vue
        |   |   |-- CollapseItem.vue
        |   |-- Inputs
        |   |   |-- BaseCheckbox.vue
        |   |   |-- BaseInput.vue
        |   |   |-- BaseRadio.vue
        |   |-- Navbar
        |   |   |-- BaseNav.vue
        |   |   |-- NavbarToggleButton.vue
        |   |-- NotificationPlugin
        |   |   |-- index.js
        |   |   |-- Notification.vue
        |   |   |-- Notifications.vue
        |   |-- SidebarPlugin
        |   |   |-- index.js
        |   |   |-- SideBar.vue
        |   |   |-- SidebarItem.vue
        |   |-- Tabs
        |   |   |-- Tab.vue
        |   |   |-- Tabs.vue
        |-- directives
        |   |-- click-ouside.js
        |-- plugins
        |   |-- dashboard-plugin.js
        |   |-- globalComponents.js
        |   |-- globalDirectives.js
        |-- routes
        |   |-- router.js
        |   |-- routes.js
        |   |-- starterRouter.js
        |-- util
        |   |-- throttle.js
        |-- views
            |-- Dashboard.vue
            |-- GoogleMaps.vue
            |-- Icons.vue
            |-- NotFoundPage.vue
            |-- RegularTables.vue
            |-- Dashboard
            |   |-- PageVisitsTable.vue
            |   |-- SocialTrafficTable.vue
            |-- Layout
            |   |-- Content.vue
            |   |-- ContentFooter.vue
            |   |-- DashboardLayout.vue
            |   |-- DashboardNavbar.vue
            |-- Maps
                |-- APY_KEY.js
            |-- Pages
                |-- UserProfile
                |-- AuthLayout.vue
                |-- Login.vue
                |-- Register.vue
                |-- UserProfile.vue
            |-- Starter
                |-- SampleFooter.vue
                |-- SampleLayout.vue
                |-- SampleNavbar.vue
                |-- SamplePage.vue
            |-- Tables
                |-- RegularTables
                |-- projects.js
                |-- users.js
        |-- App.vue
        |-- main.js
        |-- polyfills.js
```

## 浏览器支持

目前，我们官方的支持目标是以下浏览器的最新两个版本：

<img src="https://github.com/creativetimofficial/public-assets/blob/master/logos/chrome-logo.png?raw=true" width="64" height="64"> <img src="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/logos/firefox-logo.png" width="64" height="64"> <img src="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/logos/edge-logo.png" width="64" height="64"> <img src="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/logos/safari-logo.png" width="64" height="64"> <img src="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/logos/opera-logo.png" width="64" height="64">

## 资源
- 演示: <https://demos.creative-tim.com/bootstrap-vue-argon-dashboard/#/dashboard?ref=bvad-github-readme>
- 下载页面: <https://www.creative-tim.com/product/bootstrap-vue-argon-dashboard?ref=bvad-github-readme>
- 文档: <https://www.creative-tim.com/learning-lab/bootstrap-vue/colors/argon-dashboard?ref=bvad-github-readme>
- 许可协议: <https://www.creative-tim.com/license?ref=bvad-github-readme>
- 支持: <https://www.creative-tim.com/contact-us?ref=bvad-github-readme>
- 问题: [Github 问题页面](https://github.com/creativetimofficial/bootstrap-vue-argon-dashboard/issues?ref=bvad-github-readme)

## 报告问题

我们使用 GitHub Issues 作为 BootstrapVue Argon Dashboard 的官方错误追踪器。以下是一些建议，供希望报告问题的用户参考：

1. 确保您使用的是最新版本的 BootstrapVue Argon Dashboard。请在我们的[网站](https://www.creative-tim.com/?ref=bvad-github-readme)上检查您的仪表板的 CHANGELOG。
2. 提供可重现问题的步骤将缩短修复时间。
3. 一些问题可能是浏览器特定的，因此指定您遇到问题的浏览器可能会有所帮助。

## 许可

- 版权所有 2020 Creative Tim (https://www.creative-tim.com/?ref=bvad-github-readme)
- 根据 MIT 许可证授权 (https://github.com/creativetimofficial/vue-argon-dashboard/blob/master/LICENSE.md)

## 有用的链接

- [教程](https://www.youtube.com/channel/UCVyTG4sCw-rOvB9oHkzZD1w?ref=creativetim)
- [联盟计划](https://www.creative-tim.com/affiliates/new?ref=bvad-github-readme) (赚取收入)
- [Creative Tim 博客](http://blog.creative-tim.com/?ref=bvad-github-readme)
- Creative Tim 的[免费产品](https://www.creative-tim.com/bootstrap-themes/free?ref=bvad-github-readme)
- Creative Tim 的[高级产品](https://www.creative-tim.com/bootstrap-themes/premium?ref=bvad-github-readme)
- Creative Tim 的[React 产品](https://www.creative-tim.com/bootstrap-themes/react-themes?ref=bvad-github-readme)
- Creative Tim 的[Angular 产品](https://www.creative-tim.com/bootstrap-themes/angular-themes?ref=bvad-github-readme)
- Creative Tim 的[VueJS 产品](https://www.creative-tim.com/bootstrap-themes/vuejs-themes?ref=bvad-github-readme)
- Creative Tim 的[更多产品](https://www.creative-tim.com/bootstrap-themes?ref=bvad-github-readme)
- 查看我们的 [Bundles](https://www.creative-tim.com/bundles?ref=bvad-github-readme)

### 社交媒体

Twitter: <https://twitter.com/CreativeTim?ref=creativetim>

Facebook: <https://www.facebook.com/CreativeTim?ref=creativetim>

Dribbble: <https://dribbble.com/creativetim?ref=creativetim>

Instagram: <https://www.instagram.com/CreativeTimOfficial?ref=creativetim>